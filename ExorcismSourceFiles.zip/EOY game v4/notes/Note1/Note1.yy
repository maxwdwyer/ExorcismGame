{
  "$GMNotes":"v1",
  "%Name":"Note1",
  "name":"Note1",
  "parent":{
    "name":"EOY game v4",
    "path":"EOY game v4.yyp",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}