taken = false
ptaken = false