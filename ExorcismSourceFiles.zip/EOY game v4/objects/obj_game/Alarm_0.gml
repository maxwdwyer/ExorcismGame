scr_start()
