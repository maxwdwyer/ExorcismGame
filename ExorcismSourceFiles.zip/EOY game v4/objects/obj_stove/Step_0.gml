if on = true then image_index = 1
if on = false then image_index = 0
if instance_exists(obj_pot){
	if place_meeting(x, y, obj_pot) then on = true else on = false
}