pos = VecCreate()
if image_xscale = 3 and pos.z = 1 then goesto = 0
if pos.z = 2 then goesto = 1
if image_xscale != 3 and pos.z = 1 then goesto = 2
if pos.z = 0 then goesto = 1
connect = self
alarm[0] = 1
array_push(global.stairs, self)