if image_xscale = 3 and pos.z = 1 then draw_sprite(spr_stairs, 0, x, y)
if image_xscale = 3 and pos.z = 0 then draw_sprite(spr_stairs, 1, x, y)
if image_xscale != 3 and pos.z != 0 then draw_self()