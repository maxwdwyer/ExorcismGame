if goesto != 1{
	for (var _i = 0; _i < instance_number(obj_stair); _i += 1){
		var _other = instance_find(obj_stair, _i)
		if _other.pos.z = goesto {
			connect = _other 
			_other.connect = self
		}
	}
}