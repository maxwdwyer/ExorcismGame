//draw_text_transformed(x, y, goesto, 4, 4, 0)
//draw_line(x, y, connect.x, connect.y)