var _dark = .62
for (var _i = 0; _i < instance_number(obj_lightswitch) - 1; _i ++){
	var _ls = instance_find(obj_lightswitch, _i)
	if _ls.cid = obj_player.cid{
		if _ls.on = true then _dark = .325
		break
	}
}

draw_set_color(make_color_rgb(50, 50, 50))
draw_set_alpha(_dark)
gpu_set_blendequation(bm_subtract)
draw_rectangle(0, 0, room_width, room_height, false) // eeeeeeeeeeeeeeeeeeeeee
gpu_set_blendequation(bm_add)
gpu_set_blendmode(bm_normal)
draw_set_color(c_white)
draw_set_alpha(1)
if ready = true{
	for (var _i = 0; _i < array_length(global.stairs); _i += 1){
		//draw_text_transformed(global.stairs[_i].x + 25, global.stairs[_i].y + 25, _i, 4, 4, 0)
	}}
ready = true
/*var _w = view_get_wport(view_current)
var _h = view_get_hport(view_current)

surf = surface_create(_w, _h)
surface_set_target(surf)

for (var _i = 0; _i < instance_number(obj_light); _i += 1){
	var _tlb = instance_find(obj_light, _i)
	if _tlb.on = true then scr_draw_lights(_tlb.lights)
}
surface_reset_target()
draw_surface(surf, 0, 0)

surface_free(surf)*/
/*var _ols = []
var _multix = 1 / room_width
var _multiy = 1 / room_height
var _cid = obj_player.cid
for (var _i = 0; _i < instance_number(obj_light); _i += 1){
	var _tlb = instance_find(obj_light, _i)
	
	if _tlb.cid = _cid and _tlb.on = true then array_push(_ols, _tlb.x * _multix, _tlb.y * _multiy, 2.75)
	if _tlb.cid = _cid and _tlb.on = false then array_push(_ols, _tlb.x * _multix, _tlb.y * _multiy, .03)
}

_ols[23] = 0

shader_set(shd_lighting)
var _lights = shader_get_uniform(shd_lighting, "lights")
shader_set_uniform_f_array(_lights, _ols)

var _res = shader_get_uniform(shd_lighting, "resolution")
shader_set_uniform_f(_res, room_width, room_height)

draw_sprite_ext(spr_darkness, 0, room_width / 2, room_height / 2, 4, 2, 0, c_black, 1)

shader_reset()