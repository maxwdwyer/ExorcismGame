draw_self()
