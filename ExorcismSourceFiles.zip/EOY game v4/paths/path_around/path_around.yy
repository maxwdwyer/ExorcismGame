{
  "$GMPath":"",
  "%Name":"path_around",
  "closed":true,
  "kind":0,
  "name":"path_around",
  "parent":{
    "name":"EOY game v4",
    "path":"EOY game v4.yyp",
  },
  "points":[
    {"speed":100.0,"x":64.0,"y":0.0,},
    {"speed":100.0,"x":1344.0,"y":0.0,},
    {"speed":100.0,"x":1344.0,"y":800.0,},
    {"speed":100.0,"x":64.0,"y":800.0,},
  ],
  "precision":4,
  "resourceType":"GMPath",
  "resourceVersion":"2.0",
}