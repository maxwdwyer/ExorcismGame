varying vec2 v_vTexcoord;
varying vec4 v_vColour;

uniform sampler2D background;

void main() {
    vec4 light = texture2D(gm_BaseTexture, v_vTexcoord);
    vec4 bg = texture2D(background, v_vTexcoord);

	float A = light.a + 1.;

	float R = bg.r * ((bg.r * 1.525) * A * A * A * A * A);
	float G = bg.g * ((bg.g * 1.525) * A * A * A * A * A);
	float B = bg.b * ((bg.b * 1.525) * A * A * A * A * A);
	
	vec4 final = vec4(R, G, B, light.a);
	
	/*float _max = 0;
	
	if (bg.r > bg.g & bg.r > bg.b)
	{
		_max = 1. / bg.r; 
	}
	if (bg.g > bg.r & bg.g > bg.b)
	{
		_max = 1. / bg.g; 
	}
	if (bg.b > bg.g & bg.b > bg.r)
	{
		_max = 1. / bg.b; 
	}
	
	float R2 = bg.r * _max;
	float G2 = bg.g * _max;
	float B2 = bg.b * _max;
	
	vec4 final2 = vec4(R2, G2, B2, light.a);*/

    gl_FragColor = final;
}