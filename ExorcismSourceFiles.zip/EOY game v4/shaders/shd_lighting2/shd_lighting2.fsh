varying vec2 v_vTexcoord;
varying vec4 v_vColour;

uniform vec3 light;

void main()
{
	vec2 uv = gl_FragCoord.xy / 4256.;
	vec2 lightt = light.xy / 4256.;
	vec4 col = v_vColour * texture2D( gm_BaseTexture, v_vTexcoord );
	float dist = distance(uv, lightt) / .32;
	float alpha = (.6 -  smoothstep(0.0, .9, dist)) * 1.;
    gl_FragColor = vec4(.38, .35, .34, alpha);
}
