varying vec2 v_vTexcoord;
varying vec4 v_vColour;

uniform float lights[24];
uniform vec2 resolution;


void main()
{

	vec2 uv = gl_FragCoord.xy / resolution;
	float alpha = 1.0;
	float div = 0.0;
	float px = 1. / 2176.;
	float py = 1. / 4256.;
	if (lights[2] != 0.){div+=1.;}
	if (lights[5] != 0.){div+=1.;}
	if (lights[8] != 0.){div+=1.;}
	if (lights[11] != 0.){div+=1.;}
	if (lights[14] != 0.){div+=1.;}
	if (lights[17] != 0.){div+=1.;}
	
	if (lights[2] != 0.){
		vec2 second1 = vec2( (lights[0]), (lights[1]));
		float dist1 = distance(uv, second1);
		alpha -= clamp(smoothstep(0.002, .07 * lights[2], dist1) / div, 0.05, .97);
	}
	if (lights[5] != 0.){
		vec2 second2 = vec2( (lights[3]), (lights[4]));
		float dist2 = distance(uv, second2);
		alpha -= clamp(smoothstep(0.002, .07 * lights[5], dist2) / div, 0.05, .97);
	}
	if (lights[8] != 0.){
		vec2 second3 = vec2( (lights[6]), (lights[7]));
		float dist3 = distance(uv, second3);
		alpha -= clamp(smoothstep(0.002, .07 * lights[8], dist3) / div, 0.05, .97);
	}
	if (lights[11] != 0.){
		vec2 second4 = vec2( (lights[9]), (lights[10]));
		float dist4 = distance(uv, second4);
		alpha -= clamp(smoothstep(0.002, .07 * lights[11], dist4) / div, 0.05, .97);
	}
	if (lights[14] != 0.){
		vec2 second5 = vec2( (lights[12]), (lights[13]));
		float dist5 = distance(uv, second5);
		alpha -= clamp(smoothstep(0.002, .07 * lights[14], dist5) / div, 0.05, .97);
	}
	if (lights[17] != 0.){
		vec2 second6 = vec2( (lights[15]), (lights[16]));
		float dist6 = distance(uv, second6);
		alpha -= clamp(smoothstep(0.002, .07 * lights[17], dist6) / div, 0.05, .97);
	}
	
    gl_FragColor = vec4(0., 0., 0., 0.95 - alpha);
}



