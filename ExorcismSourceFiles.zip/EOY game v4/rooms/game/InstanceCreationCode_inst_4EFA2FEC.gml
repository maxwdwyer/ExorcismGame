sprite_index = spr_ladderup
image_yscale = 1