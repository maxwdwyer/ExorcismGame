sprite_index = spr_ladderdown
image_yscale = 1